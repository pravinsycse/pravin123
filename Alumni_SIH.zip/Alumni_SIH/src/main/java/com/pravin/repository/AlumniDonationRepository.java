package com.pravin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pravin.entity.AlumniDonationEntity;

public interface AlumniDonationRepository extends JpaRepository<AlumniDonationEntity, Integer> {

}
