package com.pravin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumniSihApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlumniSihApplication.class, args);
	}

}
