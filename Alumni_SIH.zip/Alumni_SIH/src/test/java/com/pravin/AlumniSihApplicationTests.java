package com.pravin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlumniSihApplicationTests {

	@Test
	void contextLoads() {
	}

}
